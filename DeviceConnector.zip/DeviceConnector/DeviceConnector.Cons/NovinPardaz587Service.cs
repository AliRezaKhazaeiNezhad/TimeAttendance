﻿
using System;
using Request;
using Response;
using System.Collections.Generic;
using DeviceConnector.ViewModel.Response;

namespace Service
{
    public class NovinPardaz587Service
    {
        #region Ctor

        public NovinPardaz587Service(DeviceRequestViewModel tADeviceRequest)
        {
            _tADeviceRequest = tADeviceRequest;

            _ipAddress = _tADeviceRequest.IpAddress;
            _deviceNumber = _tADeviceRequest.DeviceNumber;
            _portNumber = _tADeviceRequest.PortNumber;
        }

        #endregion


        #region Propertices

        private DeviceRequestViewModel _tADeviceRequest { get; }

        private string _ipAddress { get; }
        private int _deviceNumber { get; }
        private int _portNumber { get; }

        #endregion


        #region Methods

        /// <summary>
        /// لیست کلیه کاربران سخت افزار را دریافت میکند
        /// </summary>
        /// <returns></returns>
        public List<EnrollResponseViewModel> EnrollList()
        {
            Connect();
            Disable();

            List<EnrollResponseViewModel> enrollList = new List<EnrollResponseViewModel>();

            try
            {
                if (FKAttendDLL.FK_ReadAllUserID(FKAttendDLL.nCommHandleIndex) == 1)
                {
                    do
                    {
                        UInt32 vEnrollNumber = 0;
                        int vBackupNumber = 0;
                        int vPrivilege = (int)enumMachinePrivilege.MP_NONE;
                        int vnEnableFlag = 0;
                        string vName = "";

                        if (FKAttendDLL.FK_GetAllUserID(FKAttendDLL.nCommHandleIndex,
                            ref vEnrollNumber,
                            ref vBackupNumber,
                            ref vPrivilege,
                            ref vnEnableFlag) == 1)
                        {

                            if (FKAttendDLL.FK_GetUserName(FKAttendDLL.nCommHandleIndex, vEnrollNumber, ref vName) == 1)
                            {
                                EnrollResponseViewModel model = new EnrollResponseViewModel();

                                model.Enable = vnEnableFlag == 1 ? true : false;
                                model.EnrollNumber = int.Parse(vEnrollNumber.ToString());
                                model.Privilege = vPrivilege;
                                model.Name = vName;

                                enrollList.Add(model);
                            }
                        }
                        else
                        {
                            break;
                        }

                    }
                    while (true);
                }
            }
            catch (Exception e)
            {

            }

            Enable();
            DisConnect();

            return enrollList;
        }

        /// <summary>
        /// تغییر زمان و تاریخ دستگاه
        /// </summary>
        /// <returns></returns>
        public bool SetDateTime(DateTime dateTime)
        {
            Connect();
            Disable();

            bool result = false;

            try
            {
                int code = FKAttendDLL.FK_SetDeviceTime(FKAttendDLL.nCommHandleIndex, dateTime);

                result = code == 1 ? true : false;
            }
            catch (Exception e)
            {
            }

            Enable();
            DisConnect();

            return result;
        }

        /// <summary>
        /// خاموش کردن دستگاه
        /// </summary>
        /// <returns></returns>
        public bool PowerOff()
        {
            Connect();
            Disable();

            bool result = false;

            try
            {
                int code = FKAttendDLL.FK_PowerOffDevice(FKAttendDLL.nCommHandleIndex);

                result = code == 1 ? true : false;
            }
            catch (Exception e)
            {
            }

            return result;
        }

        /// <summary>
        /// دریافت ترددهای ثبت شده در دستگاه
        /// </summary>
        /// <returns></returns>
        public List<LogResponseViewModel> GetLog()
        {
            Connect();
            Disable();

            List<LogResponseViewModel> modelList = new List<LogResponseViewModel>();

            UInt32 vSEnrollNumber = 0;
            string vStrEnrollNumber;
            int vVerifyMode = 0;
            int vInOutMode = 0;
            int vWorkCode = 0;
            DateTime vdwDate = DateTime.MinValue;
            int vnCount;
            int vnResultCode = 0;
            string vstrFileName;
            string vstrFileData;
            int vnReadMark;

            vstrFileName = "";



            vnResultCode = FKAttendDLL.FK_EnableDevice(FKAttendDLL.nCommHandleIndex, 0);
            if (vnResultCode == 0)
            {
            }

            //در این بخش مشخص میکند آیا کل لاگ ها را دریافت کند یا فقط لاگ های خوانده نشده را
            //1 یعنی نمایش لاگ های خوانده نشده
            //if (chkReadMark.CheckState == CheckState.Checked)
            //    vnReadMark = 1;
            //else
            //    vnReadMark = 0;



            vnCount = 1;
            int vnResultSupportStringID = FKAttendDLL.FK_GetIsSupportStringID(FKAttendDLL.nCommHandleIndex);

            if (vnResultSupportStringID >= (int)enumErrorCode.RUN_SUCCESS)
            {
                do
                {
                   
                } while (true);
            }
            else
            {
                do
                {
                    vnResultCode = FKAttendDLL.FK_GetGeneralLogData(FKAttendDLL.nCommHandleIndex, ref vSEnrollNumber, ref vVerifyMode, ref vInOutMode, ref vdwDate);
                    if (vnResultCode != (int)enumErrorCode.RUN_SUCCESS)
                    {
                        if (vnResultCode == (int)enumErrorCode.RUNERR_DATAARRAY_END)
                        {
                            vnResultCode = (int)enumErrorCode.RUN_SUCCESS;
                        }
                        break;
                    }

                    //if (funcShowGeneralLogDataToGrid(vnCount, "", vSEnrollNumber, vVerifyMode, vInOutMode, vdwDate) == false) break;
                    vnCount = vnCount + 1;
                } while (true);
            }
            

            Enable();
            DisConnect();

            return modelList;
        }

        #endregion


        #region Private Methods

        /// <summary>
        /// اتصال به دستگاه
        /// </summary>
        /// <returns></returns>
        private bool Connect()
        {
            bool result = false;

            int state = FKAttendDLL.FK_ConnectNet(_deviceNumber, _ipAddress, _portNumber, 5000, 0, 0, 1261);

            result = state == 1 ? true : false;

            return result;
        }

        /// <summary>
        /// قطع اتصال از دستگاه
        /// </summary>
        private void DisConnect()
        {
            FKAttendDLL.FK_DisConnect(FKAttendDLL.nCommHandleIndex);
        }

        /// <summary>
        /// فعال کردن دستگاه
        /// </summary>
        /// <returns></returns>
        private bool Enable()
        {
            bool result = false;

            int state = FKAttendDLL.FK_EnableDevice(FKAttendDLL.nCommHandleIndex, 1);

            result = state == 1 ? true : false;

            return result;
        }

        /// <summary>
        /// غیرفغال کردن دستگاه
        /// </summary>
        /// <returns></returns>
        private bool Disable()
        {
            bool result = false;

            int state = FKAttendDLL.FK_EnableDevice(FKAttendDLL.nCommHandleIndex, 0);

            result = state == 1 ? true : false;

            return result;
        }

        #endregion



    }
}
