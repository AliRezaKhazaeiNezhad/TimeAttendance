﻿
using System;

namespace Request
{
    public class DeviceRequestViewModel
    {
        #region Ctor

        public DeviceRequestViewModel(string ipAddress, int deviceNumber, int portNumber)
        {
            if (string.IsNullOrEmpty(ipAddress))
            {
                throw new Exception($"{nameof(ipAddress)} is null");
            }

            if (ipAddress.Length > 15)
            {
                throw new Exception($"{nameof(ipAddress)} must be 15 character length");
            }

            if (deviceNumber <= 0)
            {
                throw new Exception($"{nameof(deviceNumber)} must be greater than 0");
            }

            if (portNumber <= 0)
            {
                throw new Exception($"{nameof(portNumber)} must be greater than 0");
            }


            IpAddress = ipAddress;
            DeviceNumber = deviceNumber;
            PortNumber = portNumber;
        }

        #endregion


        #region Propertices

        public string IpAddress { get; }
        public int DeviceNumber { get; }
        public int PortNumber { get; }

        #endregion
    }
}
