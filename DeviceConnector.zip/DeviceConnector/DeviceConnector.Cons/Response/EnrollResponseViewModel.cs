﻿
namespace Response
{
    public class EnrollResponseViewModel
    {
        #region Ctor

        public EnrollResponseViewModel()
        {

        }

        #endregion


        #region Propertices

        public int EnrollNumber { get; set; }
        public int Privilege { get; set; }
        public bool Enable { get; set; }
        public string Name { get; set; }

        #endregion
    }
}
