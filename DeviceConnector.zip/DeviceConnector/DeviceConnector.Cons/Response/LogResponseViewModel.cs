﻿
using System;

namespace DeviceConnector.ViewModel.Response
{
    public class LogResponseViewModel
    {
        #region Ctor

        public LogResponseViewModel()
        {

        }

        #endregion


        #region Propertices
        public int EnrollNumber { get; set; }
        public int VerifyMode { get; set; }
        public int InOutMode { get; set; }
        public DateTime DateTime { get; set; }
        public int WorkCode { get; set; }

        #endregion
    }
}
