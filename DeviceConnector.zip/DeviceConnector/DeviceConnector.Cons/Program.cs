﻿
using Request;
using Service;
using System;

namespace DeviceConnector.Cons
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                DeviceRequestViewModel model = new DeviceRequestViewModel("192.168.1.224", 1, 5005);
                NovinPardaz587Service service = new NovinPardaz587Service(model);

                //var list = service.EnrollList();

                //DateTime dt;
                //dt = DateTime.Now;
                //service.SetDateTime(dt);

                //service.PowerOff();

                var list = service.GetLog();

                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            Console.ReadKey();
        }
    }
}
